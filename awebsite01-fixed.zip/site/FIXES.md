# Weekly leaderboard + Liverpool skin fix

This version fixes two issues in the previous build:

1. **Weekly leaderboard migration:** the existing `submit_score` function returned `void`, so PostgreSQL rejected the migration when it tried to replace it with a `jsonb` return type. The migration now drops the old function before recreating it.
2. **Weekly rewards:** a `claim_weekly_reward` function now lets the previous week's top 3 collect their prize when they open the game. Rewards are one-time per player/week.
3. **Liverpool skin:** the crest is mounted on the front of the 3D ball, so it is visible during gameplay and in the skin shop. It is drawn locally and does not depend on an external image URL.

## Supabase

Apply the migration in `supabase/migrations/20260915000000_weekly_leaderboard_rewards.sql` to the same Supabase project used by the game. If you deploy through a workflow that automatically runs Supabase migrations, redeploy this project.

The prize amounts are:
- 1st: 500 coins
- 2nd: 250 coins
- 3rd: 100 coins

The weekly leaderboard uses the highest score a player records during the Monday-Sunday week.
