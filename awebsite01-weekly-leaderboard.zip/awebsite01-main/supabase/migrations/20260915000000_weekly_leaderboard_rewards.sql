CREATE TABLE public.weekly_leaderboard (
  week_start date NOT NULL,
  player_id uuid NOT NULL,
  name text NOT NULL,
  best_distance integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (week_start, player_id)
);

GRANT SELECT ON public.weekly_leaderboard TO anon;
GRANT SELECT ON public.weekly_leaderboard TO authenticated;
GRANT ALL ON public.weekly_leaderboard TO service_role;

ALTER TABLE public.weekly_leaderboard ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Weekly leaderboard is publicly readable"
  ON public.weekly_leaderboard FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE INDEX weekly_leaderboard_score_idx
  ON public.weekly_leaderboard (week_start, best_distance DESC);

CREATE TABLE public.weekly_rewards (
  week_start date NOT NULL,
  player_id uuid NOT NULL,
  reward integer NOT NULL,
  claimed_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (week_start, player_id)
);

GRANT ALL ON public.weekly_rewards TO service_role;
ALTER TABLE public.weekly_rewards ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.submit_score(_player_id uuid, _name text, _distance integer)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  clean_name text;
  current_week date := date_trunc('week', now())::date;
  previous_week date := (date_trunc('week', now())::date - 7);
  previous_rank integer;
  previous_score integer;
  reward_amount integer := 0;
BEGIN
  clean_name := btrim(_name);
  IF clean_name = '' THEN
    RAISE EXCEPTION 'Name is required';
  END IF;
  clean_name := left(clean_name, 16);

  IF _distance IS NULL OR _distance < 0 OR _distance > 10000000 THEN
    RAISE EXCEPTION 'Invalid distance';
  END IF;

  INSERT INTO public.leaderboard (player_id, name, best_distance)
  VALUES (_player_id, clean_name, _distance)
  ON CONFLICT (player_id) DO UPDATE
  SET name = EXCLUDED.name,
      best_distance = GREATEST(public.leaderboard.best_distance, EXCLUDED.best_distance),
      updated_at = now();

  INSERT INTO public.weekly_leaderboard (week_start, player_id, name, best_distance)
  VALUES (current_week, _player_id, clean_name, _distance)
  ON CONFLICT (week_start, player_id) DO UPDATE
  SET name = EXCLUDED.name,
      best_distance = GREATEST(public.weekly_leaderboard.best_distance, EXCLUDED.best_distance),
      updated_at = now();

  -- When a new week starts, pay the previous week's top 3 the final prizes.
  -- The reward is claimed once per player/week, so it cannot be collected twice.
  SELECT rank, best_distance
  INTO previous_rank, previous_score
  FROM (
    SELECT
      player_id,
      best_distance,
      row_number() OVER (ORDER BY best_distance DESC, player_id ASC) AS rank
    FROM public.weekly_leaderboard
    WHERE week_start = previous_week
  ) ranked
  WHERE player_id = _player_id;

  IF previous_rank = 1 THEN
    reward_amount := 500;
  ELSIF previous_rank = 2 THEN
    reward_amount := 250;
  ELSIF previous_rank = 3 THEN
    reward_amount := 100;
  END IF;

  IF reward_amount > 0 THEN
    INSERT INTO public.weekly_rewards (week_start, player_id, reward)
    VALUES (previous_week, _player_id, reward_amount)
    ON CONFLICT (week_start, player_id) DO NOTHING;

    IF NOT FOUND THEN
      reward_amount := 0;
    END IF;
  END IF;

  RETURN jsonb_build_object('reward', reward_amount);
END;
$$;

GRANT EXECUTE ON FUNCTION public.submit_score(uuid, text, integer) TO anon, authenticated, service_role;
